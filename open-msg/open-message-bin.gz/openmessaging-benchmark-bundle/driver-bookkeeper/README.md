# Apache BookKeeper benchmarks

Apache BookKeeper is the storage used by Apache Pulsar. This driver allows benchmarking Apache BookKeeper directly using the OpenMessaging benchmark
framework. For more details see the official pulsar [benchmark documentation](http://openmessaging.cloud/docs/benchmarks/pulsar/).
